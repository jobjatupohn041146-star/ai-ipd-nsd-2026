# Accuracy Test Results — excel-report-analyst

**ประเภท:** Real — รันโค้ดจริง · คำสั่ง: `python tests/run_accuracy_test.py`
**ข้อมูล:** `tests/fixtures/census-sample.xlsx` สร้างโดย `tests/fixtures/make_fixtures.py` (ข้อมูลสมมติ)
- 3 หอผู้ป่วยสมมติ (Ward-A/B/C) × 10 วัน (1–10 ม.ค. 2026) = 30 แถว
- แถวซ้ำโดยตั้งใจ 1 แถว (Ward-B วันที่ 5 ม.ค. รับใหม่ 3) วางไว้ห่างจากแถวต้นฉบับ → รวม 31 แถว
- มีชีต README เป็นชีตที่ 2 (ทดสอบว่าเลือกชีตข้อมูลถูก)
- ค่าคาดหวังคำนวณจากรายการในตัวสร้างไฟล์ ไม่ได้มาจากสคริปต์ที่ถูกทดสอบ → `fixtures/expected.json`

## ผล
```
PASS exit code 0
PASS total excluding duplicate = 170
PASS total including duplicate = 173
PASS duplicate flagged at row 19
PASS per-ward totals match            (Ward-A 59, Ward-B 33, Ward-C 78)
PASS no missing dates reported
PASS all internal reconciliation checks pass
PASS PII file → exit code 3 (stopped)
PASS PII output does not echo fake HN/name values
```

## ทดสอบกรณีขอบเพิ่มเติม (รันระหว่างพัฒนา)
| กรณี | ผล |
|---|---|
| แถว "รวม" ปนในตาราง | ตัดออกจากการคำนวณ แจ้งเลขแถว ✅ |
| ค่าว่างในคอลัมน์ตัวเลข | แจ้งเลขแถว ✅ |
| ลบ 1 วันของ Ward-C | รายงาน `{'Ward-C': ['2026-01-07']}` ✅ |
| 2 ไฟล์ชื่อคอลัมน์ต่างกัน | หยุด exit 4 แสดงคอลัมน์รายไฟล์ ✅ → ใช้ `--rename` แล้วรวมได้ ยอดรายไฟล์ = ยอดรวม ✅ |
| ชื่อพร้อมคำนำหน้าซ่อนในคอลัมน์หมายเหตุ | ตรวจจากค่าในเซลล์ exit 3 ✅ |

## บั๊กที่พบและแก้ระหว่างทดสอบ
- pandas 3.0 เก็บค่าว่างเป็น NaN แม้แปลงเป็น str → การตรวจแถวรวมล่ม · แก้แล้ว
- โหมด profile อ่านคอลัมน์วันที่เป็นตัวเลข · แก้แล้ว

## ขอบเขตที่การทดสอบนี้ไม่ครอบคลุม
- การที่ Claude **เรียกใช้สคริปต์จริง** แทนคิดเลขเอง (ต้องดูใน Live test)
- ไฟล์ที่มี merged cells / หัวตารางหลายแถว / ปี พ.ศ.
- การคำนวณอัตราที่ Claude เขียน pandas เอง นอกสคริปต์
