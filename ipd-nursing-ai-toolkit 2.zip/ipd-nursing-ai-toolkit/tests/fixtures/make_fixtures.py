#!/usr/bin/env python3
"""สร้างไฟล์ทดสอบสมมติ (fictional) สำหรับ accuracy test และ safety test ของ excel-report-analyst

- census-sample.xlsx       : 3 หอผู้ป่วยสมมติ x 10 วัน + แถวซ้ำ 1 แถว (ไม่มีข้อมูลระบุตัวตน)
- census-with-fake-hn.xlsx : มีคอลัมน์ HN และชื่อผู้ป่วย "ปลอม" เพื่อทดสอบว่าสคริปต์หยุดทำงาน

ค่าคาดหวัง (ground truth) คำนวณจากรายการที่สร้างที่นี่ ไม่ได้มาจาก reconcile_report.py
"""
import json
from datetime import date, timedelta
from pathlib import Path

from openpyxl import Workbook
from openpyxl.styles import Font

HERE = Path(__file__).parent
WARDS = ["Ward-A", "Ward-B", "Ward-C"]
ADMITS = {  # รับใหม่ต่อวัน (สมมติ)
    "Ward-A": [5, 7, 6, 4, 8, 5, 6, 7, 5, 6],
    "Ward-B": [3, 4, 2, 5, 3, 4, 3, 2, 4, 3],
    "Ward-C": [8, 6, 9, 7, 10, 8, 7, 9, 6, 8],
}
DISCHARGES = {
    "Ward-A": [4, 6, 5, 5, 7, 6, 5, 6, 6, 5],
    "Ward-B": [2, 3, 3, 4, 3, 3, 4, 2, 3, 3],
    "Ward-C": [7, 7, 8, 8, 9, 7, 8, 8, 7, 7],
}
START = date(2026, 1, 1)
DUP_DAY, DUP_WARD = 4, "Ward-B"  # วันที่ 5 ม.ค. 2026 ของ Ward-B ถูกกรอกซ้ำ


def rows():
    out = []
    for d in range(10):
        for w in WARDS:
            out.append([START + timedelta(days=d), w, ADMITS[w][d], DISCHARGES[w][d]])
    return out


def style_header(ws):
    for c in ws[1]:
        c.font = Font(name="Arial", bold=True)


def main():
    data = rows()
    truth = {
        "admit_total_excluding_duplicate": sum(r[2] for r in data),
        "discharge_total_excluding_duplicate": sum(r[3] for r in data),
        "admit_by_ward": {w: sum(ADMITS[w]) for w in WARDS},
    }
    dup = next(r for r in data if r[0] == START + timedelta(days=DUP_DAY) and r[1] == DUP_WARD)
    insert_at = data.index(dup) + 4  # วางแถวซ้ำห่างออกไป ไม่ติดกัน
    data_with_dup = data[:insert_at] + [list(dup)] + data[insert_at:]
    truth["admit_total_including_duplicate"] = truth["admit_total_excluding_duplicate"] + dup[2]
    truth["duplicate_excel_row"] = insert_at + 2  # +1 หัวตาราง +1 นับจาก 1
    truth["duplicate_of"] = {"date": str(dup[0]), "ward": dup[1], "admit": dup[2]}
    truth["data_rows_in_file"] = len(data_with_dup)

    wb = Workbook()
    ws = wb.active
    ws.title = "census"
    ws.append(["วันที่", "หอผู้ป่วย", "รับใหม่", "จำหน่าย"])
    for r in data_with_dup:
        ws.append(r)
    for row in ws.iter_rows(min_row=2, max_col=1):
        row[0].number_format = "yyyy-mm-dd"
    style_header(ws)
    note = wb.create_sheet("README")
    note.append(["ข้อมูลสมมติทั้งหมด (fictional) สำหรับทดสอบ excel-report-analyst — ไม่ใช่ข้อมูลจริงของหน่วยงานใด"])
    note.append([f"มีแถวซ้ำโดยตั้งใจ 1 แถว: {dup[1]} วันที่ {dup[0]}"])
    wb.save(HERE / "census-sample.xlsx")

    wb2 = Workbook()
    ws2 = wb2.active
    ws2.title = "census"
    ws2.append(["วันที่", "HN", "ชื่อผู้ป่วย", "หอผู้ป่วย", "รับใหม่"])
    ws2.append([START, "TEST-000001", "นายทดสอบ สมมติ", "Ward-A", 1])
    ws2.append([START, "TEST-000002", "นางสาวตัวอย่าง ปลอม", "Ward-B", 1])
    style_header(ws2)
    wb2.save(HERE / "census-with-fake-hn.xlsx")

    (HERE / "expected.json").write_text(json.dumps(truth, ensure_ascii=False, indent=2, default=str), encoding="utf-8")
    print(json.dumps(truth, ensure_ascii=False, indent=2, default=str))


if __name__ == "__main__":
    main()
