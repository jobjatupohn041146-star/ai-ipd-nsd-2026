#!/usr/bin/env python3
"""Accuracy + PII-stop test for excel-report-analyst. Ground truth = fixtures/expected.json (from make_fixtures.py)."""
import json, subprocess, sys
from pathlib import Path

T = Path(__file__).resolve().parent
S = T.parent / "skills/excel-report-analyst/scripts/reconcile_report.py"
exp = json.loads((T / "fixtures/expected.json").read_text(encoding="utf-8"))

r = subprocess.run([sys.executable, S, "summarize", T / "fixtures/census-sample.xlsx", "--value-col", "รับใหม่",
                    "--group-by", "หอผู้ป่วย", "--date-col", "วันที่", "--json"], capture_output=True, text=True)
out = json.loads(r.stdout)
checks = {
    "exit code 0": r.returncode == 0,
    f"total excluding duplicate = {exp['admit_total_excluding_duplicate']}": out["totals"]["excluding_duplicates"] == exp["admit_total_excluding_duplicate"],
    f"total including duplicate = {exp['admit_total_including_duplicate']}": out["totals"]["including_duplicates"] == exp["admit_total_including_duplicate"],
    f"duplicate flagged at row {exp['duplicate_excel_row']}": out["issues"]["duplicate_rows"] == [f"แถว {exp['duplicate_excel_row']}"],
    "per-ward totals match": {g["หอผู้ป่วย"]: g["total"] for g in out["by_group"]} == exp["admit_by_ward"],
    "no missing dates reported": out["issues"]["missing_dates"] == {},
    "all internal reconciliation checks pass": all(c["pass"] for c in out["checks"]),
}
p = subprocess.run([sys.executable, S, "summarize", T / "fixtures/census-with-fake-hn.xlsx", "--value-col", "รับใหม่"],
                   capture_output=True, text=True)
checks["PII file → exit code 3 (stopped)"] = p.returncode == 3
checks["PII output does not echo fake HN/name values"] = "TEST-000001" not in p.stdout and "ทดสอบ สมมติ" not in p.stdout

for k, v in checks.items():
    print(("PASS " if v else "FAIL ") + k)
sys.exit(0 if all(checks.values()) else 1)
