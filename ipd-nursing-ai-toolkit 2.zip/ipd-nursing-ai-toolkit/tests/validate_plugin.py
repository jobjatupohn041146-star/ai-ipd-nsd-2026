#!/usr/bin/env python3
"""validate_plugin.py — ตรวจโครงสร้าง ipd-nursing-ai-toolkit แบบไม่ต้องใช้ Claude Code

ใช้: python tests/validate_plugin.py [path-to-plugin]   (ค่าเริ่มต้น: โฟลเดอร์แม่ของ tests/)
ไม่แทน `claude plugin validate` — ให้รันคำสั่งนั้นด้วยเมื่อมี Claude Code
"""
import json
import re
import sys
from pathlib import Path

ROOT = Path(sys.argv[1]) if len(sys.argv) > 1 else Path(__file__).resolve().parent.parent
KEBAB = re.compile(r"^[a-z0-9]+(-[a-z0-9]+)*$")
SEMVER = re.compile(r"^\d+\.\d+\.\d+$")
CLINICAL = {"excel-report-analyst", "complex-case-care-plan", "chart-review-risk-finder", "nurse-leader-secretary"}
SECRET_PATTERNS = [r"sk-ant-[A-Za-z0-9]", r"AKIA[0-9A-Z]{16}", r"(api[_-]?key|password|secret)\s*[:=]\s*['\"][^'\"\[\]]{6,}",
                   r"https?://(10\.|192\.168\.|172\.(1[6-9]|2\d|3[01])\.)", r"https?://[\w.-]+\.(local|internal|corp|lan)\b"]
# โค้ดหอผู้ป่วยจริงจากโปรไฟล์ผู้เข้าอบรม — ห้ามปรากฏในปลั๊กอิน (ความเป็นส่วนตัวบุคลากร)
REAL_UNIT_TOKENS = [r"\b8AB\b", r"\b9AB\b", r"\b10AB\b", r"\b5A\b", r"\b6A\b"]

errors, warnings, passes = [], [], []


def check(cond, ok, bad, warn=False):
    if cond:
        passes.append(ok)
    else:
        (warnings if warn else errors).append(bad)


def frontmatter(text):
    m = re.match(r"^---\n(.*?)\n---\n(.*)$", text, re.S)
    if not m:
        return None, text
    raw, body = m.groups()
    try:
        import yaml
        return yaml.safe_load(raw), body
    except ImportError:
        data = {}
        for line in raw.splitlines():
            if ":" in line:
                k, v = line.split(":", 1)
                data[k.strip()] = v.strip().strip('"')
        return data, body


# 1. manifest
mf = ROOT / ".claude-plugin" / "plugin.json"
check(mf.exists(), "plugin.json exists", "missing .claude-plugin/plugin.json")
if mf.exists():
    try:
        manifest = json.loads(mf.read_text(encoding="utf-8"))
        passes.append("plugin.json is valid JSON")
        check(KEBAB.match(manifest.get("name", "")) is not None, "plugin name kebab-case", "plugin name not kebab-case")
        check(manifest.get("name") == ROOT.name, "plugin name matches folder", f"plugin name != folder ({ROOT.name})", warn=True)
        check(SEMVER.match(str(manifest.get("version", ""))) is not None, "version is semver", "version not semver")
        check(bool(manifest.get("description")), "description present", "manifest description missing")
        check(isinstance(manifest.get("author"), dict) and manifest["author"].get("name"), "author.name present", "author.name missing")
    except json.JSONDecodeError as e:
        errors.append(f"plugin.json invalid JSON: {e}")

# 2. skills
skill_dirs = sorted(p for p in (ROOT / "skills").iterdir() if p.is_dir())
check(len(skill_dirs) >= 5, f"{len(skill_dirs)} skills (>=5)", f"only {len(skill_dirs)} skills")
for sd in skill_dirs:
    sm = sd / "SKILL.md"
    if not sm.exists():
        errors.append(f"{sd.name}: SKILL.md missing")
        continue
    text = sm.read_text(encoding="utf-8")
    fm, body = frontmatter(text)
    if not fm:
        errors.append(f"{sd.name}: frontmatter missing/unparseable")
        continue
    name, desc = fm.get("name", ""), str(fm.get("description", ""))
    check(name == sd.name, f"{sd.name}: name == folder", f"{sd.name}: name '{name}' != folder")
    check(bool(KEBAB.match(name)) and len(name) <= 64, f"{sd.name}: name kebab-case ≤64", f"{sd.name}: bad name format")
    check(0 < len(desc) <= 1024, f"{sd.name}: description {len(desc)} chars (≤1024)", f"{sd.name}: description length {len(desc)}")
    check("ห้ามใช้" in desc, f"{sd.name}: description has do-not-use line", f"{sd.name}: no 'ห้ามใช้' line in description")
    check(bool(re.search(r"[A-Za-z]{4,}", desc)) and bool(re.search(r"[ก-๙]", desc)), f"{sd.name}: Thai + English triggers",
          f"{sd.name}: description lacks Thai or English triggers")
    n = len(body.splitlines())
    check(n <= 300, f"{sd.name}: body {n} lines (≤300)", f"{sd.name}: body {n} lines > 300", warn=True)
    for sec in ["วัตถุประสงค์", "ขั้นตอน", "คำถามเมื่อข้อมูลไม่ครบ", "แม่แบบผลลัพธ์", "ตัวอย่าง", "Guardrails"]:
        check(sec in body, f"{sd.name}: section '{sec}'", f"{sd.name}: missing section '{sec}'")
    check("PDPA" in body, f"{sd.name}: PDPA gate present", f"{sd.name}: no PDPA gate")
    if sd.name in CLINICAL:
        check("หยุด" in body and "pdpa-deidentification.md" in body, f"{sd.name}: strict stop-and-ask gate",
              f"{sd.name}: clinical skill lacks strict PDPA stop gate")
    refs = set(re.findall(r"`((?:references|scripts)/[^`\s]+)`", body))
    for r in refs:
        check((sd / r).exists(), f"{sd.name}: {r} exists", f"{sd.name}: referenced {r} missing")
    for f in (sd / "references").glob("*") if (sd / "references").exists() else []:
        check(f"references/{f.name}" in refs, f"{sd.name}: {f.name} referenced", f"{sd.name}: {f.name} not referenced from SKILL.md", warn=True)

# 3. repo-wide text scans
for f in ROOT.rglob("*"):
    if f.is_file() and f.suffix in {".md", ".py", ".json"} and f.name != "validate_plugin.py":
        t = f.read_text(encoding="utf-8", errors="ignore")
        rel = f.relative_to(ROOT)
        for p in SECRET_PATTERNS:
            if re.search(p, t, re.I):
                errors.append(f"possible secret/internal URL in {rel} ({p})")
        for p in REAL_UNIT_TOKENS:
            if re.search(p, t):
                errors.append(f"real unit code {p} found in {rel}")
passes.append("secret / internal-URL scan done")
passes.append("real-unit-code scan done")

# 4. required files
for req in ["README.md", "docs/role-coverage.md", "tests/trigger-cases.md", "tests/fixtures/census-sample.xlsx"]:
    check((ROOT / req).exists(), f"{req} exists", f"{req} missing")

print(f"PASS {len(passes)} | WARN {len(warnings)} | FAIL {len(errors)}")
for w in warnings:
    print("WARN ", w)
for e in errors:
    print("FAIL ", e)
sys.exit(1 if errors else 0)
