# คู่มือเขียน prompt ภาพ การ์ตูน และวิดีโอ

ความสามารถและข้อจำกัดของ Veo 3, Kling, Gemini และเครื่องมืออื่นเปลี่ยนบ่อย (ความยาวคลิป ความละเอียด เสียง)
ให้ผู้ใช้ตรวจข้อจำกัดปัจจุบันในเครื่องมือ และแบ่งฉากให้สั้นพอกับข้อจำกัดนั้น

## 1. Character sheet (ทำครั้งเดียว ใช้ซ้ำทุกฉาก)
```
CHARACTER: [ชื่อเรียกในงาน เช่น Nurse Mai] — Thai female nurse, late 20s, hair tied back,
plain white nurse uniform with no logo, friendly calm expression.
PATIENT: [ชื่อเรียก] — fictional elderly Thai man, plain light-blue hospital gown.
STYLE: [3D animation soft pastel / flat 2D cartoon / realistic cinematic], consistent across all scenes.
SETTING: modern clean hospital ward, neutral colors, no brand logos, no real hospital name.
```
คัดลอกบล็อกนี้ไว้ต้นทุก prompt เพื่อลดตัวละครเปลี่ยนหน้าตา ถ้าเครื่องมือรองรับภาพอ้างอิง ให้สร้างภาพตัวละครก่อนแล้วใช้เป็น reference

## 2. โครง prompt วิดีโอ (ภาษาอังกฤษ ได้ผลสม่ำเสมอกว่า)
```
[STYLE]. [SUBJECT + ACTION ชัดเจน 1 การกระทำ]. [SETTING + TIME].
Camera: [shot size], [movement]. Lighting: [ ]. Mood: [ ]. Duration: [ตามข้อจำกัดเครื่องมือ].
No text on screen, no logos, no watermark.
Negative: gore, distorted hands, extra fingers, text, subtitles, brand logos, real people likeness.
```
- 1 prompt = 1 การกระทำหลัก ถ้าต้องมีหลายการกระทำ ให้แยกฉาก
- ระบุอุปกรณ์ทางการแพทย์ให้ชัด แต่ **ต้องตรวจภาพจริงทุกครั้ง** AI มักวาดอุปกรณ์หรือท่าทางผิด
- ถ้าเครื่องมือสร้างเสียงพูดได้ ให้ใช้เสียงบรรยายที่อัดแยกแทนสำหรับภาษาไทย เพื่อควบคุมความถูกต้อง

## 3. โครง prompt ภาพนิ่ง/การ์ตูน/infographic
```
[STYLE: flat vector cartoon / kawaii / clean medical illustration], [SUBJECT], [ACTION/POSE],
[BACKGROUND simple], [COLOR PALETTE], leave empty space at [top/bottom] for text overlay,
no text, no letters, no logos.
```
เว้นพื้นที่ว่างไว้ใส่ข้อความภาษาไทยเองในโปรแกรมตัดต่อหรือ Canva/Gamma

## 4. Image-to-video
1. สร้างภาพนิ่งที่ถูกต้องก่อน ตรวจความถูกต้องทางคลินิก
2. ใช้ภาพนั้นเป็นเฟรมเริ่ม แล้วสั่งการเคลื่อนไหวน้อยๆ เช่น `subtle breathing motion, slow camera pan`
3. การเคลื่อนไหวมากทำให้รายละเอียดเพี้ยน

## 5. สิ่งที่ห้ามและข้อควรระวัง
| ห้าม/ระวัง | เหตุผล | ทำแทน |
|---|---|---|
| ข้อความภาษาไทยในภาพ AI | มักสะกดผิดหรือตัวอักษรเพี้ยน | ใส่ข้อความตอนตัดต่อ |
| ภาพผู้ป่วยจริง ใบหน้าบุคคลจริง | PDPA และการยินยอม | ตัวละครสมมติ |
| โลโก้ ชื่อโรงพยาบาล แบรนด์ยา/อุปกรณ์ | ลิขสิทธิ์ ความเข้าใจผิด | อุปกรณ์ทั่วไปไม่มีแบรนด์ |
| ตัวละครการ์ตูนที่มีลิขสิทธิ์ | ลิขสิทธิ์ | ออกแบบตัวละครของหน่วยงานเอง |
| แผล เลือด หัตถการรุนแรง | ไม่เหมาะกับผู้ป่วย/ญาติ | ภาพสัญลักษณ์ หรือภาพประกอบทางการแพทย์แบบเรียบ |
| ขั้นตอนหัตถการละเอียดด้วย AI | AI อาจแสดงขั้นตอนผิด | ถ่ายจริงกับหุ่นฝึก |

## 6. ตัวอย่างสไตล์ที่ใช้บ่อย
- `soft 3D animation, pastel colors, rounded shapes` — เป็นมิตร เหมาะผู้ป่วย/ญาติ
- `flat 2D vector cartoon, bold outlines, limited palette` — infographic ขั้นตอน
- `clean realistic cinematic, natural hospital lighting` — สถานการณ์สำหรับพยาบาล
- `whiteboard doodle style` — อธิบายแนวคิด พยาธิสภาพอย่างง่าย
