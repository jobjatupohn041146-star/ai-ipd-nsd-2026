# Token Efficiency Playbook สำหรับ Agentic AI

"Caveman prompting" (บีบคำสั่ง/คำตอบให้สั้นแบบห้วนๆ) ลด token ได้บ้าง ส่วนใหญ่ฝั่ง output แต่แลกกับความชัดเจนและคุณภาพ
ในระบบ agent หลาย role ต้นทุนหลักมักอยู่ฝั่ง **input ที่ถูกส่งซ้ำ** (system prompt, tool definitions, ประวัติ, เอกสาร)
จึงควรแก้ที่โครงสร้างก่อนแก้ถ้อยคำ

ความสามารถและราคาของแต่ละผู้ให้บริการเปลี่ยนบ่อย ตรวจเอกสารทางการเสมอ เช่น
- Prompt caching: https://docs.claude.com/en/docs/build-with-claude/prompt-caching
- Token counting: https://docs.claude.com/en/docs/build-with-claude/token-counting
- Batch processing: https://docs.claude.com/en/docs/build-with-claude/batch-processing

## 0. วัดก่อนแก้ (บังคับ)
- บันทึก input/output tokens ต่อ call จากฟิลด์ usage ใน response แยกตาม role, tool, ขั้นของ workflow
- หา 20% ของ call ที่กิน token มากที่สุด แก้ตรงนั้นก่อน
- มีชุดทดสอบคุณภาพ (คำถาม + คำตอบที่คาดหวัง) รันก่อน-หลังทุกการเปลี่ยน ห้ามลด token แล้วคุณภาพตกโดยไม่รู้

## 1. จุดสิ้นเปลืองที่พบบ่อย → วิธีแก้
| # | จุดสิ้นเปลือง | อาการ | วิธีแก้ |
|---|---|---|---|
| 1 | บริบทคงที่ถูกส่งซ้ำทุก call | system prompt/เอกสารยาวเหมือนเดิมทุกครั้ง | **Prompt caching**: วางส่วนคงที่ไว้ต้น prompt ส่วนเปลี่ยนไว้ท้าย (Gemini มี context caching คล้ายกัน) |
| 2 | ส่งประวัติสนทนาทั้งหมดต่อ | input โตตามจำนวนรอบ | สรุปสถานะเป็นโครงสร้าง (JSON state) แทน transcript, ตัดรอบเก่า, compaction |
| 3 | agent ส่งงานกันด้วยข้อความยาว | orchestrator ได้ log เต็มของ sub-agent | ให้ sub-agent คืนผลตาม schema สั้น (ผล, หลักฐานอ้างอิง, สถานะ) ไม่คืนกระบวนการคิด |
| 4 | ทุก role เห็นทุก tool | tool definitions ยาวใน input ทุก call | กำหนด tool ต่อ role เท่าที่ใช้ รวม tool ที่ซ้ำ เขียนคำอธิบาย tool กระชับ |
| 5 | ผลลัพธ์ tool ใหญ่ | query คืนข้อมูลดิบหลายพันแถว | ให้ tool คืนเฉพาะฟิลด์ที่ต้องใช้ แบ่งหน้า รวมยอดที่ฐานข้อมูล (SQL aggregate) ก่อนส่งให้โมเดล |
| 6 | ยัดเอกสารทั้งหมดใน prompt | ใส่คู่มือทั้งเล่มทุกครั้ง | Retrieval (RAG) ดึงเฉพาะส่วนที่เกี่ยวข้อง / progressive disclosure: โหลดรายละเอียดเมื่อจำเป็น (แนวคิดเดียวกับ Skills ที่โหลด references เมื่อใช้) |
| 7 | ใช้โมเดลใหญ่ทุกงาน | งานจัดหมวด/ดึงข้อมูลใช้โมเดลเดียวกับงานวิเคราะห์ | **Model routing**: โมเดลเล็ก/เร็วสำหรับ classify, extract, route; โมเดลใหญ่เฉพาะงานให้เหตุผลซับซ้อน |
| 8 | ให้ LLM ทำงานที่โค้ดทำได้ | คำนวณ จัดรูปแบบ ตรวจ schema ด้วย LLM | ย้ายไปโค้ด deterministic (ถูกกว่าและแม่นกว่า) |
| 9 | output ยาวเกินจำเป็น | อธิบาย ทวนคำถาม ขึ้นต้นยาว | structured output ตาม schema, กำหนด max_tokens, สั่งไม่ต้องมีคำนำ |
| 10 | reasoning เกินงาน | เปิด thinking/effort สูงกับงานง่าย | ปรับระดับ reasoning ตามประเภทงาน |
| 11 | คำถามซ้ำ | ผู้ใช้ถามเรื่องเดิม | cache คำตอบระดับแอป (คำถามเหมือน/คล้าย + เอกสารไม่เปลี่ยน) |
| 12 | งานไม่เร่งด่วนรันแบบ real-time | ประมวลผลเอกสารจำนวนมากทีละ call | Batch API สำหรับงาน offline (ลดต้นทุน แม้ไม่ลดจำนวน token) |
| 13 | retry ไม่มีขอบเขต | agent วนแก้ซ้ำหลายรอบ | จำกัดจำนวนรอบ, validate output ด้วยโค้ดก่อน retry, ส่งเฉพาะ error ที่เกี่ยวข้อง |

## 2. ออกแบบ agent หลาย role ให้ประหยัด
- 1 role = 1 ความรับผิดชอบ + tool เท่าที่ใช้ + system prompt สั้น
- สถานะกลางเก็บนอกโมเดล (DB/state object) ส่งให้แต่ละ role เฉพาะส่วนที่ต้องใช้
- orchestrator ตัดสินใจจากผลสรุปของ role ไม่ใช่จาก transcript
- พิจารณาว่าจำเป็นต้องมีหลาย agent จริงไหม — workflow ตายตัวที่เรียกโมเดลตามขั้น มักถูกกว่าและคุมง่ายกว่า agent อิสระ

## 3. ในงาน vibe coding (Claude Code / Gemini CLI)
- ไฟล์บริบทสั้น (CLAUDE.md/GEMINI.md) · ชี้ไฟล์ที่ต้องแก้ · เฟสสั้นมีเกณฑ์เสร็จ
- `/compact` เมื่อยาว `/clear` เมื่อเปลี่ยนงาน · ใช้ sub-agent สำรวจโค้ดแล้วคืนสรุป แทนอ่านทุกไฟล์ใน context หลัก

## 4. แม่แบบรายงาน token audit
```
| role/ขั้น | calls/วัน | avg input | avg output | % ของทั้งหมด | จุดสิ้นเปลือง (#) | วิธีแก้ | วิธีวัดผล | ความเสี่ยงต่อคุณภาพ |
```
ใส่ตัวเลขจาก log จริงเท่านั้น ถ้าไม่มีให้ขั้นแรกของแผนคือ "เพิ่มการบันทึก usage"
