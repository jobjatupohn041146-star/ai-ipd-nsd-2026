# Prompt สร้างแอปแบบประหยัด token (Claude Code / Gemini)

หลักใหญ่: **บริบทคงที่ใส่ไฟล์ครั้งเดียว · งานแบ่งเฟสสั้น · บอกเกณฑ์ "เสร็จ" ชัด · จำกัดขอบเขตการแก้**

## 1. ไฟล์บริบท
- Claude Code อ่าน `CLAUDE.md` ในโฟลเดอร์โปรเจกต์ · Gemini CLI ใช้ `GEMINI.md` (ตรวจเอกสารเครื่องมือเวอร์ชันที่ใช้)
- เขียนสั้น เป็นข้อ ภาษาอังกฤษสำหรับคำสั่ง ข้อความหน้าจอเป็นไทย ไม่เกิน ~40 บรรทัด

```
# [App name]
## Goal
[1 sentence]
## Stack
[e.g. single-file HTML + vanilla JS / React + Vite]. No new dependencies without asking.
## Data model
[field: type — note] (fictional data only)
## Rules
- [business rules]
- Never add patient identifiers (HN, AN, name, national ID, DOB, phone, address).
- No secrets or internal URLs in code. Read config from environment variables.
## UI
Thai language, large readable fonts, works on [desktop/mobile].
## Working style
- Do only the current phase. Do not refactor unrelated code.
- Ask before deleting files or changing the data model.
- After each phase: list files changed + how to test in ≤5 lines.
```

## 2. Prompt เป็นเฟส
```
Read CLAUDE.md. Phase [n] only: [one feature].
Done when:
- [observable check 1]
- [observable check 2]
Reply with: files changed + test steps. No full code dump in chat.
```
ลำดับเฟสแนะนำ: 1) ฟอร์ม + ตาราง + ข้อมูลสมมติ 2) กฎตรวจ/กันซ้ำ 3) สรุป/กราฟ 4) ส่งออก CSV/Excel 5) ขัดเกลา UI

## 3. หลักประหยัด token ระหว่าง vibe coding
| ทำ | เพราะ |
|---|---|
| ใส่กฎถาวรใน CLAUDE.md/GEMINI.md แทนพิมพ์ซ้ำทุกข้อความ | ลดข้อความซ้ำ |
| สั่งทีละเฟส มีเกณฑ์เสร็จ | ลดการแก้ไปมาหลายรอบ |
| ระบุไฟล์/ฟังก์ชันที่ต้องแก้ | ไม่ต้องให้ AI อ่านทั้งโปรเจกต์ |
| ขอให้ตอบเฉพาะไฟล์ที่เปลี่ยน + วิธีทดสอบ | ลดข้อความตอบกลับยาว |
| ใช้ `/compact` เมื่อบทสนทนายาว และ `/clear` เมื่อเริ่มงานใหม่ใน Claude Code | ไม่ลากประวัติเก่าไปทุกข้อความ |
| แนบ error เฉพาะส่วนที่เกี่ยวข้อง ไม่วาง log ทั้งไฟล์ | ลด input |
| ใช้ข้อมูลตัวอย่าง 5–10 แถว ไม่วางไฟล์ข้อมูลใหญ่ | ลด input และปลอดภัยกว่า |
| งานเล็ก (แก้ข้อความ สี) รวมเป็นข้อความเดียว | ลดจำนวนรอบ |

## 4. ทดสอบก่อนส่งมอบ
- ทดสอบทุกเกณฑ์ "เสร็จ" ด้วยข้อมูลสมมติ รวมกรณีผิด (กรอกซ้ำ ค่าติดลบ ช่องว่าง)
- เปิดบนอุปกรณ์จริงที่หน่วยงานใช้
- ตรวจว่าไม่มีข้อมูลผู้ป่วยจริง secret หรือ URL ภายในในโค้ด
