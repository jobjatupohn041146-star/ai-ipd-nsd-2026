#!/usr/bin/env python3
"""
reconcile_report.py — ตัวช่วยคำนวณและกระทบยอดรายงาน Excel/CSV สำหรับสกิล excel-report-analyst

หลักการ: ทุกตัวเลขที่รายงานต้องมาจากโค้ด ไม่ประมาณ และต้องกระทบยอดได้

คำสั่ง
  profile    สำรวจไฟล์: ชีต คอลัมน์ ค่าว่าง แถวรวม แถวซ้ำ ช่วงวันที่
  summarize  คำนวณยอดรวม/แยกกลุ่ม ตรวจแถวซ้ำ ข้อมูลหาย วันที่ขาด และกระทบยอด

ตัวอย่าง
  python reconcile_report.py profile census.xlsx
  python reconcile_report.py summarize census.xlsx --value-col "รับใหม่" \
      --group-by "หอผู้ป่วย" --date-col "วันที่" --control-total 250

Exit codes
  0 = สำเร็จ | 2 = ใช้คำสั่งผิด/อ่านไฟล์ไม่ได้ | 3 = พบข้อมูลที่อาจระบุตัวผู้ป่วย (หยุด ไม่วิเคราะห์)
  4 = คอลัมน์ไม่ตรงกัน/ไม่พบคอลัมน์ที่ระบุ
"""
from __future__ import annotations

import argparse
import json
import re
import sys
import warnings
from pathlib import Path

import pandas as pd

# ---------------------------------------------------------------- PDPA gate
PII_HEADER_PATTERNS = [
    r"\bhn\b", r"\ban\b", r"h\.n\.", r"a\.n\.", r"\bmrn\b", r"medical record (no|number)",
    r"เลขที่?เวชระเบียน", r"ชื่อผู้ป่วย", r"ชื่อ\s*-?\s*นามสกุล", r"นามสกุล", r"ชื่อญาติ", r"^ชื่อ$",
    r"^name$", r"patient name", r"full ?name", r"first ?name", r"last ?name", r"surname",
    r"เลขบัตร", r"บัตรประชาชน", r"citizen", r"national id", r"id card", r"passport",
    r"วันเกิด", r"date of birth", r"\bdob\b", r"birth ?date",
    r"เบอร์โทร", r"โทรศัพท์", r"\bphone\b", r"\bmobile\b", r"ที่อยู่", r"\baddress\b",
    r"e-?mail", r"อีเมล", r"line ?id",
]
PII_VALUE_PATTERNS = {
    "เลขบัตรประชาชน 13 หลัก": re.compile(r"(?<!\d)(\d{13}|\d-\d{4}-\d{5}-\d{2}-\d)(?!\d)"),
    "ชื่อพร้อมคำนำหน้า": re.compile(r"(^|\s)(นาย|นางสาว|นาง|น\.ส\.|ด\.ช\.|ด\.ญ\.|เด็กชาย|เด็กหญิง)\s*[ก-๙]{2,}"),
    "HN/AN ในข้อความ": re.compile(r"\b(HN|AN|H\.N\.|A\.N\.)\s*[:.#]?\s*[\w-]*\d"),
}
TOTAL_ROW_RE = re.compile(r"^\s*(รวม|ยอดรวม|รวมทั้งหมด|ทั้งหมด|total|grand total|sum|subtotal)\s*$", re.I)
BLANK_GROUP = "(ว่าง)"


def pii_scan(df: pd.DataFrame, label: str) -> list[dict]:
    """คืนรายการคอลัมน์ที่อาจมีตัวระบุตัวตน — ไม่คืนค่าข้อมูลจริง"""
    findings = []
    for col in df.columns:
        name = str(col).strip().lower()
        if any(re.search(p, name, re.I) for p in PII_HEADER_PATTERNS):
            findings.append({"source": label, "column": str(col), "reason": "ชื่อคอลัมน์บ่งชี้ข้อมูลระบุตัวตน"})
            continue
        series = df[col].dropna().map(str)
        for reason, pat in PII_VALUE_PATTERNS.items():
            hits = int(series.map(lambda v: bool(pat.search(v))).sum())
            if hits:
                findings.append({"source": label, "column": str(col), "reason": f"ค่าในคอลัมน์ตรงรูปแบบ{reason}", "cells": hits})
                break
    return findings


# ---------------------------------------------------------------- loading
def load_table(path: str, sheet: str | None, header_row: int) -> tuple[pd.DataFrame, list[str], str]:
    p = Path(path)
    if not p.exists():
        sys.exit(f"ไม่พบไฟล์: {path}")
    header = header_row - 1
    if p.suffix.lower() in {".xlsx", ".xlsm", ".xls"}:
        sheets = list(pd.ExcelFile(p).sheet_names)
        use = sheet if sheet is not None else sheets[0]
        if use not in sheets:
            print(f"ไม่พบชีต '{use}' ในไฟล์ {p.name}; ชีตที่มี: {sheets}")
            sys.exit(4)
        df = pd.read_excel(p, sheet_name=use, header=header)
        return df, sheets, use
    if p.suffix.lower() in {".csv", ".tsv"}:
        sep = "\t" if p.suffix.lower() == ".tsv" else ","
        for enc in ("utf-8-sig", "cp874"):
            try:
                return pd.read_csv(p, sep=sep, header=header, encoding=enc), [], "(csv)"
            except UnicodeDecodeError:
                continue
        sys.exit(f"อ่านไฟล์ {p.name} ไม่ได้ (encoding)")
    sys.exit(f"ไม่รองรับนามสกุลไฟล์: {p.suffix}")


def prepare(df: pd.DataFrame, label: str, header_row: int) -> pd.DataFrame:
    df = df.dropna(how="all").copy()
    df.columns = [str(c).strip() for c in df.columns]
    df["__excel_row"] = df.index + header_row + 1  # เลขแถวตามที่เห็นใน Excel
    df["__source"] = label
    obj_cols = [c for c in df.columns if not c.startswith("__")]
    df["__is_total_row"] = df[obj_cols].apply(
        lambda r: any(isinstance(v, str) and TOTAL_ROW_RE.match(v) for v in r), axis=1).astype(bool)
    return df


def data_cols(df: pd.DataFrame) -> list[str]:
    return [c for c in df.columns if not c.startswith("__")]


def rows_ref(df: pd.DataFrame, multi: bool) -> list[str]:
    if multi:
        return [f"{s}!แถว {r}" for s, r in zip(df["__source"], df["__excel_row"])]
    return [f"แถว {r}" for r in df["__excel_row"]]


def fmt(n) -> str:
    if n is None or (isinstance(n, float) and pd.isna(n)):
        return "-"
    return f"{int(n):,}" if float(n).is_integer() else f"{n:,.2f}"


# ---------------------------------------------------------------- commands
def cmd_profile(args) -> int:
    report = {"files": []}
    all_pii = []
    for path in args.files:
        raw, sheets, used = load_table(path, args.sheet, args.header_row)
        label = Path(path).name
        all_pii += pii_scan(raw, label)
        df = prepare(raw, label, args.header_row)
        cols = data_cols(df)
        info = {
            "file": label, "sheets": sheets, "sheet_used": used, "data_rows": int(len(df)),
            "columns": [], "total_like_rows": rows_ref(df[df["__is_total_row"]], False),
        }
        body = df[~df["__is_total_row"]]
        dups = body[body.duplicated(subset=cols, keep="first")]
        info["exact_duplicate_rows"] = rows_ref(dups, False)
        for c in cols:
            s = body[c]
            entry = {"name": c, "non_blank": int(s.notna().sum()), "blank": int(s.isna().sum()),
                     "unique": int(s.nunique(dropna=True))}
            n_filled = int(s.notna().sum())
            num = pd.to_numeric(s, errors="coerce") if not pd.api.types.is_datetime64_any_dtype(s) else None
            if pd.api.types.is_datetime64_any_dtype(s):
                entry["type"] = "date"
                entry["min"], entry["max"] = str(s.min().date()), str(s.max().date())
            elif n_filled and int(num.notna().sum()) == n_filled:
                entry["type"] = "number"
                entry["sum"] = float(num.sum())
            else:
                with warnings.catch_warnings():
                    warnings.simplefilter("ignore")
                    dt = pd.to_datetime(s, errors="coerce")
                if n_filled and int(dt.notna().sum()) == n_filled:
                    entry["type"] = "date"
                    entry["min"], entry["max"] = str(dt.min().date()), str(dt.max().date())
                else:
                    entry["type"] = "text"
            info["columns"].append(entry)
        report["files"].append(info)

    if all_pii:
        return stop_for_pii(all_pii, args.json)

    if args.json:
        print(json.dumps(report, ensure_ascii=False, indent=2))
        return 0
    for f in report["files"]:
        print(f"=== ไฟล์ {f['file']} | ชีตที่ใช้: {f['sheet_used']} | ชีตทั้งหมด: {f['sheets'] or '-'}")
        print(f"จำนวนแถวข้อมูล (ไม่นับหัวตาราง/แถวว่างทั้งแถว): {f['data_rows']}")
        print("คอลัมน์:")
        for c in f["columns"]:
            extra = f", ผลรวม {fmt(c['sum'])}" if c["type"] == "number" else (
                f", ช่วง {c['min']} ถึง {c['max']}" if c["type"] == "date" else "")
            print(f"  - {c['name']} [{c['type']}] มีค่า {c['non_blank']} ว่าง {c['blank']} ค่าไม่ซ้ำ {c['unique']}{extra}")
        print(f"แถวที่ดูเหมือนแถวรวม (จะไม่นำมาคำนวณ): {f['total_like_rows'] or 'ไม่พบ'}")
        print(f"แถวซ้ำทุกคอลัมน์: {f['exact_duplicate_rows'] or 'ไม่พบ'}")
        print("หมายเหตุ: ผลรวมในโหมด profile ยังไม่ตัดแถวซ้ำ — ใช้คำสั่ง summarize เพื่อได้ยอดที่กระทบแล้ว")
    return 0


def stop_for_pii(findings: list[dict], as_json: bool) -> int:
    if as_json:
        print(json.dumps({"status": "STOPPED_PII", "findings": findings}, ensure_ascii=False, indent=2))
    else:
        print("⛔ หยุดการวิเคราะห์: พบคอลัมน์ที่อาจมีข้อมูลระบุตัวผู้ป่วย (ไม่แสดงค่าข้อมูล)")
        for f in findings:
            cells = f" ({f['cells']} เซลล์)" if "cells" in f else ""
            print(f"  - {f['source']} / คอลัมน์ '{f['column']}': {f['reason']}{cells}")
        print("กรุณาลบคอลัมน์/ข้อมูลเหล่านี้จากไฟล์ต้นทาง แล้วส่งไฟล์ใหม่")
    return 3


def cmd_summarize(args) -> int:
    frames, all_pii = [], []
    renames = dict(r.split("=", 1) for r in (args.rename or []))
    for path in args.files:
        raw, _, _ = load_table(path, args.sheet, args.header_row)
        label = Path(path).name
        all_pii += pii_scan(raw, label)
        df = prepare(raw, label, args.header_row).rename(columns=renames)
        frames.append(df)
    if all_pii:
        return stop_for_pii(all_pii, args.json)

    multi = len(frames) > 1
    colsets = {f["__source"].iloc[0] if len(f) else "?": data_cols(f) for f in frames}
    if multi and len({tuple(sorted(c)) for c in colsets.values()}) > 1:
        print("⚠️ คอลัมน์ของแต่ละไฟล์ไม่ตรงกัน — ต้องจับคู่คอลัมน์ก่อน (ใช้ --rename 'ชื่อเดิม=ชื่อใหม่')")
        for k, v in colsets.items():
            print(f"  - {k}: {v}")
        return 4

    df = pd.concat(frames, ignore_index=True)
    cols = data_cols(df)
    needed = [args.value_col] + (args.group_by or []) + ([args.date_col] if args.date_col else []) + (args.key_cols or [])
    missing_cols = [c for c in needed if c not in cols]
    if missing_cols:
        print(f"⚠️ ไม่พบคอลัมน์: {missing_cols}; คอลัมน์ที่มี: {cols}")
        return 4

    rows_in = len(df)
    total_rows = df[df["__is_total_row"]]
    body = df[~df["__is_total_row"]].copy()

    key_cols = args.key_cols or cols
    dup_mask = body.duplicated(subset=key_cols, keep="first")
    dups = body[dup_mask]
    kept = body[~dup_mask].copy()

    raw_vals = pd.to_numeric(body[args.value_col], errors="coerce")
    nonnum_mask = body[args.value_col].notna() & raw_vals.isna()
    blank_mask = body[args.value_col].isna()
    kept["__value"] = pd.to_numeric(kept[args.value_col], errors="coerce")

    raw_total = float(raw_vals.sum())
    dedup_total = float(kept["__value"].sum())
    dup_contrib = float(pd.to_numeric(dups[args.value_col], errors="coerce").sum())

    result = {
        "value_col": args.value_col,
        "row_accounting": {
            "rows_in_file": rows_in, "total_like_rows_excluded": int(len(total_rows)),
            "duplicate_rows_excluded": int(len(dups)), "rows_used": int(len(kept)),
        },
        "totals": {"including_duplicates": raw_total, "excluding_duplicates": dedup_total,
                   "duplicate_contribution": dup_contrib},
        "issues": {
            "duplicate_rows": rows_ref(dups, multi),
            "total_like_rows": rows_ref(total_rows, multi),
            "blank_value_rows": rows_ref(body[blank_mask], multi),
            "non_numeric_value_rows": rows_ref(body[nonnum_mask], multi),
        },
        "checks": [],
    }

    acc = result["row_accounting"]
    ok_rows = acc["rows_used"] + acc["duplicate_rows_excluded"] + acc["total_like_rows_excluded"] == rows_in
    result["checks"].append({"name": "นับแถวครบ (ใช้ + ซ้ำ + แถวรวม = แถวในไฟล์)", "pass": bool(ok_rows)})
    ok_dup = abs(raw_total - dup_contrib - dedup_total) < 1e-9
    result["checks"].append({"name": "ยอดรวมรวมแถวซ้ำ − ยอดของแถวซ้ำ = ยอดรวมหลังตัดแถวซ้ำ", "pass": bool(ok_dup)})

    if args.group_by:
        g = kept.copy()
        for c in args.group_by:
            g[c] = g[c].astype(object).where(g[c].notna(), BLANK_GROUP)
        table = g.groupby(args.group_by, dropna=False).agg(total=("__value", "sum"), rows=("__value", "size")).reset_index()
        group_sum = float(table["total"].sum())
        result["by_group"] = table.to_dict(orient="records")
        result["checks"].append({"name": "ผลรวมทุกกลุ่ม = ยอดรวมหลังตัดแถวซ้ำ", "pass": abs(group_sum - dedup_total) < 1e-9})

    if multi:
        per_file = kept.groupby("__source")["__value"].sum()
        result["by_source_file"] = {k: float(v) for k, v in per_file.items()}
        result["checks"].append({"name": "ผลรวมรายไฟล์ = ยอดรวมหลังตัดแถวซ้ำ",
                                 "pass": abs(float(per_file.sum()) - dedup_total) < 1e-9})

    if args.date_col:
        with warnings.catch_warnings():
            warnings.simplefilter("ignore")
            d = pd.to_datetime(kept[args.date_col], errors="coerce")
        bad_dates = kept[kept[args.date_col].notna() & d.isna()]
        result["issues"]["unparseable_date_rows"] = rows_ref(bad_dates, multi)
        if d.notna().any():
            full = pd.date_range(d.min().normalize(), d.max().normalize(), freq="D")
            result["date_range"] = [str(full.min().date()), str(full.max().date())]
            gaps = {}
            groups = kept.assign(__d=d.dt.normalize()).groupby(args.group_by) if args.group_by else [(("ทั้งหมด",), kept.assign(__d=d.dt.normalize()))]
            for key, sub in groups:
                key = key if isinstance(key, tuple) else (key,)
                absent = sorted(set(full) - set(sub["__d"].dropna()))
                if absent:
                    gaps[" / ".join(map(str, key))] = [str(x.date()) for x in absent]
            result["issues"]["missing_dates"] = gaps

    if args.control_total is not None:
        ct = args.control_total
        result["control_total"] = {
            "value": ct,
            "matches_excluding_duplicates": abs(ct - dedup_total) < 1e-9,
            "matches_including_duplicates": abs(ct - raw_total) < 1e-9,
            "difference_vs_excluding_duplicates": dedup_total - ct,
        }

    if args.json:
        print(json.dumps(result, ensure_ascii=False, indent=2, default=str))
        return 0
    print_summary(result, args)
    return 0


def print_summary(r: dict, args) -> None:
    a, t, i = r["row_accounting"], r["totals"], r["issues"]
    print(f"=== สรุปคอลัมน์ '{r['value_col']}' (คำนวณด้วยโค้ด)")
    print(f"แถวในไฟล์ {a['rows_in_file']} | ตัดแถวรวม {a['total_like_rows_excluded']} | ตัดแถวซ้ำ {a['duplicate_rows_excluded']} | ใช้คำนวณ {a['rows_used']}")
    print(f"ยอดรวมหลังตัดแถวซ้ำ (แนะนำ): {fmt(t['excluding_duplicates'])}")
    print(f"ยอดรวมถ้านับแถวซ้ำด้วย: {fmt(t['including_duplicates'])} (ส่วนต่างจากแถวซ้ำ {fmt(t['duplicate_contribution'])})")
    if "by_group" in r:
        print("\nแยกตาม " + " / ".join(args.group_by) + ":")
        for row in r["by_group"]:
            key = " / ".join(str(row[c]) for c in args.group_by)
            print(f"  - {key}: {fmt(row['total'])} ({row['rows']} แถว)")
    if "by_source_file" in r:
        print("\nแยกตามไฟล์ต้นทาง:")
        for k, v in r["by_source_file"].items():
            print(f"  - {k}: {fmt(v)}")
    print("\nประเด็นข้อมูลที่พบ:")
    labels = {"duplicate_rows": "แถวซ้ำ", "total_like_rows": "แถวรวม/ยอดรวมในตาราง", "blank_value_rows": "ค่าว่างในคอลัมน์ตัวเลข",
              "non_numeric_value_rows": "ค่าที่ไม่ใช่ตัวเลข", "unparseable_date_rows": "วันที่อ่านไม่ได้", "missing_dates": "วันที่ขาดหาย"}
    for k, lab in labels.items():
        if k in i:
            print(f"  - {lab}: {i[k] if i[k] else 'ไม่พบ'}")
    if "date_range" in r:
        print(f"ช่วงวันที่ในข้อมูล: {r['date_range'][0]} ถึง {r['date_range'][1]}")
    if "control_total" in r:
        c = r["control_total"]
        status = "ตรง" if c["matches_excluding_duplicates"] else ("ตรงเฉพาะเมื่อนับแถวซ้ำ" if c["matches_including_duplicates"] else "ไม่ตรง")
        print(f"\nยอดควบคุม {fmt(c['value'])}: {status} (ต่างจากยอดหลังตัดซ้ำ {fmt(c['difference_vs_excluding_duplicates'])})")
    print("\nการกระทบยอด:")
    for c in r["checks"]:
        print(f"  {'✅' if c['pass'] else '❌'} {c['name']}")


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    sub = ap.add_subparsers(dest="cmd", required=True)
    common = argparse.ArgumentParser(add_help=False)
    common.add_argument("files", nargs="+")
    common.add_argument("--sheet", default=None, help="ชื่อชีต (ค่าเริ่มต้น: ชีตแรก)")
    common.add_argument("--header-row", type=int, default=1, help="แถวหัวตาราง (นับจาก 1)")
    common.add_argument("--json", action="store_true")
    sub.add_parser("profile", parents=[common])
    s = sub.add_parser("summarize", parents=[common])
    s.add_argument("--value-col", required=True)
    s.add_argument("--group-by", nargs="*")
    s.add_argument("--date-col")
    s.add_argument("--key-cols", nargs="*", help="คอลัมน์ที่ใช้ตัดสินแถวซ้ำ (ค่าเริ่มต้น: ทุกคอลัมน์)")
    s.add_argument("--control-total", type=float)
    s.add_argument("--rename", nargs="*", help="จับคู่คอลัมน์ข้ามไฟล์ 'ชื่อเดิม=ชื่อใหม่'")
    args = ap.parse_args()
    return cmd_profile(args) if args.cmd == "profile" else cmd_summarize(args)


if __name__ == "__main__":
    sys.exit(main())
